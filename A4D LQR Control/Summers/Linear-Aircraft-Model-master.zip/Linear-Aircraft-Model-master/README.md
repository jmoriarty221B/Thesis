# Linear-Aircraft-Model
Developed a simulink model of the full state feedback of a Linear Aircraft model and implemented its Kalman gain, generated open loop and closed loop state and control responses and modified the Q and R values of an LQR filter to achieve the requirements.
