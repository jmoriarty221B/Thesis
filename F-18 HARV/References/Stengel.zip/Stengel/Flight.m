    
    Mach    =   0.75;    %   Initial Mach Number
    hm      =   10500; 
    [airDens,airPres,temp,soundSpeed] = Atmos(hm);
    V       =   Mach*soundSpeed
    D2R =   pi/180;
    R2D =   180/pi;
    alpha   =	0.0;    % Angle of attack, deg (relative to air mass)
	beta    =	0;      % Sideslip angle, deg (relative to air mass)
	dA      =	0;      % Aileron angle, deg
	dE      =	0;      % Elevator angle, deg
	dR      =	0;      % Rudder angle, deg
	dT      = 	0.4;    % Throttle setting, % / 100
	hdot    =	0;      % Altitude rate, m/s
	p       =	0;      % Body-axis roll rate, deg/s
	phi     =	0;      % Body roll angle wrt earth, deg
	psi     =	0;      % Body yaw angle wrt earth, deg
	q       =	0;      % Body-axis pitch rate, deg/sec
	r       =	0;      % Body-axis yaw rate, deg/s
	theta   =	alpha;  % Body pitch angle wrt earth,
	xe      =	0;      % Initial longitudinal position, m
	ye      = 	0;      % Initial lateral position, m
	ze      = 	-hm;    % Initial vertical position, m [h: + up, z: + down]

%	Initial Conditions
	gamma	=	R2D * atan(hdot / sqrt(V^2 - hdot^2));
	qbar	= 	0.5 * airDens * V^2;	
    phir	=	phi * D2R;
	thetar	=	theta * D2R;
	psir	=	psi * D2R;

	windb	=	WindField(-ze,phir,thetar,psir);
    windb   =   [0; 0; 0];
	alphar	=	alpha * D2R;
	betar	=	beta * D2R;
display('Print for FUN')

	x	=[V * cos(alphar) * cos(betar) - windb(1)
			V * sin(betar) - windb(2)
			V * sin(alphar) * cos(betar) - windb(3)
			xe
			ye
			ze
			p * D2R
			q * D2R
			r * D2R
			phir
			thetar
			psir]
	
	u	=	[dE * D2R
			dA * D2R
			dR * D2R
            dT];
        
 [A, B] = Linearization(x, u)
 A(1,1) = 0.0367;
 Q = diag([1 1 1 1 1 1 1 1 1 10000 1 1]);
 R = eye(4);
 C = eye(12);
 [K] = lqr(A, B, Q, R)
%  [K] = zeros(4,12)
 