function[Fmodel, Gmodel] = Linearization(x, u)
%LINEARIZATION

thresh	=	[.1;.1;.1;.1;.1;.1;.1;.1;.1;.1;.1;.1;.1;.1;.1;.1];
xj		=	[x;u];
ti=0;
uTemp   =   u;  % 'numjac' modifies 'u'; reset 'u' after the call
xdotj		=	LinModel(ti,xj);
[dFdX,fac]	=	numjac('LinModel',ti,xj,xdotj,thresh,[],0);
xdot        =   xdotj(1:12);
u           =   uTemp;
Fmodel		=	dFdX(1:12,1:12)
Gmodel		=	dFdX(1:12,13:16)
% save ('FmodelFile','Fmodel','TASms','hm','TrimAlphaDeg')
% save ('GmodelFile','Gmodel')